<img src="{{ url('/images/logomigo.png') }}" {{ $attributes }}>
  