<x-guest-layout>
	<style>
	h2 {
		text-align: center;
	}
	img {
		height: 150px;
		width: 600px;
	}
	</style>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-800 dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                   <h2> {{ __("Registration is disabled atm...") }} </h2>
                </div>
            </div>
        </div>
    </div>
</x-guest-layout>
